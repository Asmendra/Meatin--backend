export interface Message {
  id: string;
  text: string;
  sender: 'me' | 'partner';
  timestamp: Date;
}

export interface FloatingEmoji {
  id: string;
  emoji: string;
  x: number;
  y: number;
  timestamp: Date;
}

export interface ConnectionStatus {
  isConnected: boolean;
  isSearching: boolean;
  partnerId: string | null;
}

export interface SocketEvents {
  'user-connected': (id: string) => void;
  'user-disconnected': () => void;
  'receive-offer': (data: { offer: RTCSessionDescriptionInit; caller: string }) => void;
  'receive-answer': (data: { answer: RTCSessionDescriptionInit }) => void;
  'receive-ice-candidate': (data: { candidate: RTCIceCandidateInit }) => void;
  'receive-message': (data: { text: string; id: string }) => void;
  'receive-emoji': (data: { emoji: FloatingEmoji }) => void;
  'chat-ended': () => void;
  'partner-liked': () => void;
  'partner-disliked': () => void;
}