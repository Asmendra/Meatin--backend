import React, { useEffect, useRef, useState, useCallback } from 'react';
import { EmojiClickData } from 'emoji-picker-react';
import { v4 as uuidv4 } from 'uuid';
import { Camera, Mic, AlertCircle } from 'lucide-react';
import VideoStream from './VideoStream';
import ChatMessages from './ChatMessages';
import EmojiReactions from './EmojiReactions';
import ActionButtons from './ActionButtons';
import ConnectionStatus from './ConnectionStatus';
import { useSocket } from '../hooks/useSocket';
import { useWebRTC } from '../hooks/useWebRTC';
import { Message, FloatingEmoji } from '../types';

// Try multiple server URLs for better connectivity
const getServerUrl = () => {
  const protocol = window.location.protocol === 'https:' ? 'https:' : 'http:';
  const hostname = window.location.hostname;
  
  // Try different port configurations
  const possibleUrls = [
    `${protocol}//${hostname}:3001`,
    `${protocol}//${hostname}:3000`,
    `${window.location.origin.replace(/:\d+/, '')}:3001`,
    'http://localhost:3001',
    'http://127.0.0.1:3001'
  ];
  
  return possibleUrls[0]; // Start with the first one
};

const VideoChat: React.FC = () => {
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  
  const [partnerId, setPartnerId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [emojis, setEmojis] = useState<FloatingEmoji[]>([]);
  const [swipeDirection, setSwipeDirection] = useState<'left' | 'right' | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [serverError, setServerError] = useState(false);
  const [mediaAccessDenied, setMediaAccessDenied] = useState(false);

  const { socket, connectionStatus } = useSocket(getServerUrl());
  const {
    peerConnectionRef,
    createPeerConnection,
    addLocalStream,
    createOffer,
    handleOffer,
    handleAnswer,
    handleIceCandidate,
    closePeerConnection,
  } = useWebRTC(socket, partnerId);

  // Monitor connection status
  useEffect(() => {
    if (connectionStatus === 'error') {
      setServerError(true);
      setIsSearching(false);
    } else if (connectionStatus === 'connected') {
      setServerError(false);
    }
  }, [connectionStatus]);

  // Initialize media stream
  useEffect(() => {
    const initializeMedia = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: 1280, height: 720 },
          audio: true,
        });
        
        setLocalStream(stream);
        setMediaAccessDenied(false);
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Error accessing media devices:', error);
        
        // Check if the error is due to permission denial
        if (error instanceof DOMException && 
            (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError')) {
          setMediaAccessDenied(true);
        }
      }
    };

    initializeMedia();

    return () => {
      if (localStream) {
        localStream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  // Socket event handlers
  useEffect(() => {
    if (!socket || connectionStatus !== 'connected') return;

    const handleUserJoined = (id: string) => {
      console.log('User joined:', id);
      setPartnerId(id);
      setIsSearching(false);
      
      const pc = createPeerConnection();
      if (localStream) {
        addLocalStream(localStream);
      }
      
      pc.ontrack = (event) => {
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = event.streams[0];
        }
      };
      
      createOffer();
    };

    const handleOffer = async (data: { offer: RTCSessionDescriptionInit; sender: string }) => {
      console.log('Received offer from:', data.sender);
      setPartnerId(data.sender);
      setIsSearching(false);
      
      const pc = createPeerConnection();
      if (localStream) {
        addLocalStream(localStream);
      }
      
      pc.ontrack = (event) => {
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = event.streams[0];
        }
      };
      
      await handleOffer(data.offer, data.sender);
    };

    const handleAnswer = (data: { answer: RTCSessionDescriptionInit }) => {
      console.log('Received answer');
      handleAnswer(data.answer);
    };

    const handleIceCandidate = (data: { candidate: RTCIceCandidateInit }) => {
      console.log('Received ICE candidate');
      handleIceCandidate(data.candidate);
    };

    const handleChatMessage = (data: { message: string; sender: string; timestamp: string }) => {
      const message: Message = {
        id: uuidv4(),
        text: data.message,
        sender: 'partner',
        timestamp: new Date(data.timestamp),
      };
      setMessages(prev => [...prev, message]);
    };

    const handleEmojiReaction = (data: { emoji: string; sender: string; timestamp: string }) => {
      const emoji: FloatingEmoji = {
        id: uuidv4(),
        emoji: data.emoji,
        x: Math.random() * 80 + 10,
        y: Math.random() * 60 + 20,
        timestamp: new Date(data.timestamp),
      };
      setEmojis(prev => [...prev, emoji]);
    };

    const handleUserLeft = () => {
      console.log('User left');
      setPartnerId(null);
      setMessages([]);
      setEmojis([]);
      setIsSearching(false);
      closePeerConnection();
      
      if (remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = null;
      }
    };

    socket.on('user-joined', handleUserJoined);
    socket.on('offer', handleOffer);
    socket.on('answer', handleAnswer);
    socket.on('ice-candidate', handleIceCandidate);
    socket.on('chat-message', handleChatMessage);
    socket.on('emoji-reaction', handleEmojiReaction);
    socket.on('user-left', handleUserLeft);

    return () => {
      socket.off('user-joined', handleUserJoined);
      socket.off('offer', handleOffer);
      socket.off('answer', handleAnswer);
      socket.off('ice-candidate', handleIceCandidate);
      socket.off('chat-message', handleChatMessage);
      socket.off('emoji-reaction', handleEmojiReaction);
      socket.off('user-left', handleUserLeft);
    };
  }, [socket, connectionStatus, localStream, createPeerConnection, addLocalStream, createOffer, handleOffer, handleAnswer, handleIceCandidate, closePeerConnection]);

  const sendMessage = useCallback(() => {
    if (!input.trim() || !socket || !partnerId || connectionStatus !== 'connected') return;

    const message: Message = {
      id: uuidv4(),
      text: input,
      sender: 'me',
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, message]);
    socket.emit('chat-message', { 
      message: input, 
      roomId: `room-${[socket.id, partnerId].sort().join('-')}` 
    });
    setInput('');
  }, [input, socket, partnerId, connectionStatus]);

  const handleEmojiClick = useCallback((emojiData: EmojiClickData) => {
    if (!socket || !partnerId || connectionStatus !== 'connected') return;

    const emoji: FloatingEmoji = {
      id: uuidv4(),
      emoji: emojiData.emoji,
      x: Math.random() * 80 + 10,
      y: Math.random() * 60 + 20,
      timestamp: new Date(),
    };

    setEmojis(prev => [...prev, emoji]);
    socket.emit('emoji-reaction', { 
      emoji: emojiData.emoji, 
      roomId: `room-${[socket.id, partnerId].sort().join('-')}` 
    });
  }, [socket, partnerId, connectionStatus]);

  const endChat = useCallback(() => {
    if (!socket || !partnerId || connectionStatus !== 'connected') return;

    setPartnerId(null);
    setMessages([]);
    setEmojis([]);
    setIsSearching(false);
    closePeerConnection();
    
    if (remoteVideoRef.current) {
      remoteVideoRef.current.srcObject = null;
    }
    
    // Leave the current room and find a new partner
    socket.emit('leave-room');
  }, [socket, partnerId, connectionStatus, closePeerConnection]);

  const handleLike = useCallback(() => {
    if (!socket || !partnerId || connectionStatus !== 'connected') return;
    
    setSwipeDirection('right');
    setTimeout(() => setSwipeDirection(null), 1000);
    
    endChat();
  }, [socket, partnerId, connectionStatus, endChat]);

  const handleDislike = useCallback(() => {
    if (!socket || !partnerId || connectionStatus !== 'connected') return;
    
    setSwipeDirection('left');
    setTimeout(() => setSwipeDirection(null), 1000);
    
    endChat();
  }, [socket, partnerId, connectionStatus, endChat]);

  const startNewChat = useCallback(() => {
    if (!socket || connectionStatus !== 'connected') return;
    
    setIsSearching(true);
    const roomId = `room-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    socket.emit('join-room', roomId);
  }, [socket, connectionStatus]);

  const retryMediaAccess = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 1280, height: 720 },
        audio: true,
      });
      
      setLocalStream(stream);
      setMediaAccessDenied(false);
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error('Error accessing media devices:', error);
      if (error instanceof DOMException && 
          (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError')) {
        setMediaAccessDenied(true);
      }
    }
  }, []);

  const isConnected = Boolean(partnerId);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-4">
      {/* Server Error Banner */}
      {serverError && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 bg-red-500/90 text-white px-6 py-4 rounded-lg shadow-lg backdrop-blur-sm max-w-md">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-6 h-6 mt-0.5 flex-shrink-0" />
            <div>
              <div className="font-medium mb-2">Connection Issues Detected</div>
              <p className="text-sm opacity-90 mb-3">
                Unable to connect to the video chat server. This could be due to:
              </p>
              <ul className="text-sm opacity-90 mb-3 list-disc list-inside space-y-1">
                <li>Internet connection issues</li>
                <li>Server is not running (port 3001)</li>
                <li>Firewall blocking the connection</li>
                <li>Network configuration problems</li>
              </ul>
              <div className="text-xs opacity-75 mb-3">
                <strong>Troubleshooting steps:</strong><br/>
                1. Check your internet connection<br/>
                2. Ensure the backend server is running<br/>
                3. Try refreshing the page<br/>
                4. Check browser console for detailed errors
              </div>
              <p className="text-sm opacity-90">
                The app will automatically retry connecting when the server becomes available.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Media Access Denied Banner */}
      {mediaAccessDenied && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 bg-orange-500/90 text-white px-6 py-4 rounded-lg shadow-lg backdrop-blur-sm max-w-md">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-6 h-6 mt-0.5 flex-shrink-0" />
            <div>
              <div className="flex items-center space-x-2 mb-2">
                <Camera className="w-4 h-4" />
                <Mic className="w-4 h-4" />
                <span className="font-medium">Camera & Microphone Access Required</span>
              </div>
              <p className="text-sm opacity-90 mb-3">
                Video chat requires access to your camera and microphone. Please allow permissions and try again.
              </p>
              <div className="flex space-x-2">
                <button
                  onClick={retryMediaAccess}
                  className="bg-white/20 hover:bg-white/30 px-3 py-1 rounded text-sm font-medium transition-colors"
                >
                  Try Again
                </button>
                <button
                  onClick={() => setMediaAccessDenied(false)}
                  className="bg-white/10 hover:bg-white/20 px-3 py-1 rounded text-sm transition-colors"
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Swipe Direction Indicators */}
      {swipeDirection && (
        <div className="fixed inset-0 flex items-center justify-center z-50 pointer-events-none">
          <div className={`text-6xl font-bold animate-pulse ${
            swipeDirection === 'left' ? 'text-red-400' : 'text-green-400'
          }`}>
            {swipeDirection === 'left' ? '❌ PASS' : '❤️ LIKE'}
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">VideoChatApp</h1>
          <p className="text-white/70">Connect with strangers around the world</p>
        </div>

        {/* Connection Status */}
        <div className="flex justify-center mb-6">
          <ConnectionStatus
            isConnected={isConnected}
            isSearching={isSearching}
            partnerId={partnerId}
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Video Streams */}
          <div className="lg:col-span-2 space-y-4">
            {/* Remote Video (Partner) */}
            <div className="aspect-video">
              <VideoStream
                ref={remoteVideoRef}
                isConnected={isConnected}
                className="w-full h-full"
              />
            </div>
            
            {/* Local Video (You) */}
            <div className="aspect-video max-w-sm">
              <VideoStream
                ref={localVideoRef}
                isLocal
                isConnected={true}
                className="w-full h-full"
              />
            </div>
          </div>

          {/* Chat Panel */}
          <div className="space-y-4">
            <ChatMessages
              messages={messages}
              input={input}
              onInputChange={setInput}
              onSendMessage={sendMessage}
              isConnected={isConnected && connectionStatus === 'connected'}
            />
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-8">
          <ActionButtons
            onLike={handleLike}
            onDislike={handleDislike}
            onEndChat={endChat}
            onNewChat={startNewChat}
            isConnected={isConnected && connectionStatus === 'connected'}
            swipeDirection={swipeDirection}
          />
          
          <EmojiReactions
            emojis={emojis}
            onEmojiClick={handleEmojiClick}
            isConnected={isConnected && connectionStatus === 'connected'}
          />
        </div>
      </div>
    </div>
  );
};

export default VideoChat;