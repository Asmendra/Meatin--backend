import React, { useState } from 'react';
import { Heart, X, PhoneOff, RotateCcw } from 'lucide-react';

interface ActionButtonsProps {
  onLike: () => void;
  onDislike: () => void;
  onEndChat: () => void;
  onNewChat: () => void;
  isConnected: boolean;
  swipeDirection: 'left' | 'right' | null;
}

const ActionButtons: React.FC<ActionButtonsProps> = ({
  onLike,
  onDislike,
  onEndChat,
  onNewChat,
  isConnected,
  swipeDirection
}) => {
  const [showEndConfirm, setShowEndConfirm] = useState(false);

  const handleEndChat = () => {
    if (showEndConfirm) {
      onEndChat();
      setShowEndConfirm(false);
    } else {
      setShowEndConfirm(true);
      setTimeout(() => setShowEndConfirm(false), 3000);
    }
  };

  return (
    <div className="flex justify-center space-x-4">
      {/* Dislike Button */}
      <button
        onClick={onDislike}
        disabled={!isConnected}
        className={`group relative bg-red-500/20 hover:bg-red-500/30 disabled:bg-gray-500/20 disabled:cursor-not-allowed backdrop-blur-sm border border-red-500/30 text-red-400 p-4 rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-red-500 ${
          swipeDirection === 'left' ? 'scale-110 bg-red-500/40' : ''
        }`}
        title="Dislike and next"
      >
        <X className="w-6 h-6 group-hover:scale-110 transition-transform duration-200" />
      </button>

      {/* End Chat Button */}
      <button
        onClick={handleEndChat}
        disabled={!isConnected}
        className={`relative bg-gray-500/20 hover:bg-gray-500/30 disabled:bg-gray-500/20 disabled:cursor-not-allowed backdrop-blur-sm border border-gray-500/30 text-gray-400 p-4 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-gray-500 ${
          showEndConfirm ? 'bg-red-500/30 border-red-500/50 text-red-400' : ''
        }`}
        title={showEndConfirm ? "Click again to confirm" : "End chat"}
      >
        <PhoneOff className="w-6 h-6" />
        {showEndConfirm && (
          <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-black/80 text-white px-2 py-1 rounded text-sm whitespace-nowrap">
            Click again to confirm
          </div>
        )}
      </button>

      {/* New Chat Button */}
      {!isConnected && (
        <button
          onClick={onNewChat}
          className="bg-blue-500/20 hover:bg-blue-500/30 backdrop-blur-sm border border-blue-500/30 text-blue-400 p-4 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          title="Start new chat"
        >
          <RotateCcw className="w-6 h-6" />
        </button>
      )}

      {/* Like Button */}
      <button
        onClick={onLike}
        disabled={!isConnected}
        className={`group relative bg-green-500/20 hover:bg-green-500/30 disabled:bg-gray-500/20 disabled:cursor-not-allowed backdrop-blur-sm border border-green-500/30 text-green-400 p-4 rounded-full transition-all duration-300 focus:outline-none focus:ring-2 focus:ring-green-500 ${
          swipeDirection === 'right' ? 'scale-110 bg-green-500/40' : ''
        }`}
        title="Like and next"
      >
        <Heart className="w-6 h-6 group-hover:scale-110 transition-transform duration-200" />
      </button>
    </div>
  );
};

export default ActionButtons;