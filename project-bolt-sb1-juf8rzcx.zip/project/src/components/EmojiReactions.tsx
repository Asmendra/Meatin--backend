import React, { useState, useEffect } from 'react';
import EmojiPicker, { EmojiClickData } from 'emoji-picker-react';
import { Smile } from 'lucide-react';
import { FloatingEmoji } from '../types';

interface EmojiReactionsProps {
  emojis: FloatingEmoji[];
  onEmojiClick: (emojiData: EmojiClickData) => void;
  isConnected: boolean;
}

const EmojiReactions: React.FC<EmojiReactionsProps> = ({
  emojis,
  onEmojiClick,
  isConnected
}) => {
  const [showPicker, setShowPicker] = useState(false);
  const [visibleEmojis, setVisibleEmojis] = useState<FloatingEmoji[]>([]);

  useEffect(() => {
    const newEmojis = emojis.filter(emoji => 
      Date.now() - emoji.timestamp.getTime() < 3000
    );
    setVisibleEmojis(newEmojis);

    const cleanup = setTimeout(() => {
      setVisibleEmojis(prev => 
        prev.filter(emoji => Date.now() - emoji.timestamp.getTime() < 3000)
      );
    }, 100);

    return () => clearTimeout(cleanup);
  }, [emojis]);

  return (
    <>
      {/* Floating Emojis */}
      <div className="fixed inset-0 pointer-events-none z-30">
        {visibleEmojis.map((emoji) => (
          <div
            key={emoji.id}
            className="absolute text-4xl animate-bounce"
            style={{
              left: `${emoji.x}%`,
              top: `${emoji.y}%`,
              animation: `float 3s ease-out forwards`,
            }}
          >
            {emoji.emoji}
          </div>
        ))}
      </div>

      {/* Emoji Picker Button */}
      <div className="relative">
        <button
          onClick={() => setShowPicker(!showPicker)}
          disabled={!isConnected}
          className="bg-white/10 hover:bg-white/20 disabled:bg-gray-500/50 disabled:cursor-not-allowed backdrop-blur-sm border border-white/20 text-white p-3 rounded-full transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          title="Send emoji reaction"
        >
          <Smile className="w-6 h-6" />
        </button>

        {/* Emoji Picker */}
        {showPicker && (
          <div className="absolute bottom-full right-0 mb-2 z-40">
            <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
              <EmojiPicker
                onEmojiClick={onEmojiClick}
                width={300}
                height={400}
                searchDisabled
                skinTonesDisabled
                previewConfig={{ showPreview: false }}
              />
            </div>
          </div>
        )}
      </div>

      <style jsx>{`
        @keyframes float {
          0% {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
          50% {
            opacity: 0.8;
            transform: translateY(-50px) scale(1.2);
          }
          100% {
            opacity: 0;
            transform: translateY(-100px) scale(0.8);
          }
        }
      `}</style>
    </>
  );
};

export default EmojiReactions;