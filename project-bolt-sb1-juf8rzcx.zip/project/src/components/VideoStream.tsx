import React, { forwardRef } from 'react';
import { User, UserX } from 'lucide-react';

interface VideoStreamProps {
  isLocal?: boolean;
  isConnected?: boolean;
  className?: string;
}

const VideoStream = forwardRef<HTMLVideoElement, VideoStreamProps>(
  ({ isLocal = false, isConnected = false, className = '' }, ref) => {
    return (
      <div className={`relative overflow-hidden rounded-2xl shadow-2xl ${className}`}>
        <video
          ref={ref}
          autoPlay
          muted={isLocal}
          playsInline
          className="w-full h-full object-cover bg-gray-900"
        />
        
        {/* Connection Status Overlay */}
        {!isConnected && !isLocal && (
          <div className="absolute inset-0 bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center">
            <div className="text-center text-white">
              <UserX className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg font-medium">Waiting for connection...</p>
              <div className="mt-4 flex justify-center space-x-1">
                <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-white rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        
        {/* Local Video Label */}
        {isLocal && (
          <div className="absolute top-4 left-4 bg-black/50 px-3 py-1 rounded-full">
            <div className="flex items-center space-x-2 text-white text-sm">
              <User className="w-4 h-4" />
              <span>You</span>
            </div>
          </div>
        )}
        
        {/* Connection Indicator */}
        {isConnected && !isLocal && (
          <div className="absolute top-4 right-4 bg-green-500/90 px-3 py-1 rounded-full">
            <div className="flex items-center space-x-2 text-white text-sm">
              <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
              <span>Connected</span>
            </div>
          </div>
        )}
      </div>
    );
  }
);

VideoStream.displayName = 'VideoStream';

export default VideoStream;