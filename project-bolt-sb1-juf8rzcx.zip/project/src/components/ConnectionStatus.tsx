import React from 'react';
import { Wifi, WifiOff, Search } from 'lucide-react';

interface ConnectionStatusProps {
  isConnected: boolean;
  isSearching: boolean;
  partnerId: string | null;
}

const ConnectionStatus: React.FC<ConnectionStatusProps> = ({
  isConnected,
  isSearching,
  partnerId
}) => {
  const getStatusInfo = () => {
    if (isConnected && partnerId) {
      return {
        icon: <Wifi className="w-5 h-5" />,
        text: 'Connected',
        color: 'text-green-400 border-green-500/30 bg-green-500/10'
      };
    } else if (isSearching) {
      return {
        icon: <Search className="w-5 h-5 animate-spin" />,
        text: 'Searching for partner...',
        color: 'text-yellow-400 border-yellow-500/30 bg-yellow-500/10'
      };
    } else {
      return {
        icon: <WifiOff className="w-5 h-5" />,
        text: 'Disconnected',
        color: 'text-red-400 border-red-500/30 bg-red-500/10'
      };
    }
  };

  const status = getStatusInfo();

  return (
    <div className={`flex items-center space-x-2 px-4 py-2 rounded-full backdrop-blur-sm border ${status.color} transition-all duration-300`}>
      {status.icon}
      <span className="text-sm font-medium">{status.text}</span>
      {isSearching && (
        <div className="flex space-x-1">
          <div className="w-1 h-1 bg-current rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
          <div className="w-1 h-1 bg-current rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
          <div className="w-1 h-1 bg-current rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
        </div>
      )}
    </div>
  );
};

export default ConnectionStatus;