import { useRef, useCallback } from 'react';
import { Socket } from 'socket.io-client';

export const useWebRTC = (socket: Socket | null, partnerId: string | null) => {
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);

  const createPeerConnection = useCallback(() => {
    const pc = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' },
      ],
    });

    pc.onicecandidate = (event) => {
      if (event.candidate && socket && partnerId) {
        socket.emit('send-ice-candidate', {
          candidate: event.candidate,
          target: partnerId,
        });
      }
    };

    pc.onconnectionstatechange = () => {
      console.log('Connection state:', pc.connectionState);
    };

    pc.oniceconnectionstatechange = () => {
      console.log('ICE connection state:', pc.iceConnectionState);
    };

    peerConnectionRef.current = pc;
    return pc;
  }, [socket, partnerId]);

  const addLocalStream = useCallback((stream: MediaStream) => {
    localStreamRef.current = stream;
    if (peerConnectionRef.current) {
      stream.getTracks().forEach(track => {
        peerConnectionRef.current!.addTrack(track, stream);
      });
    }
  }, []);

  const createOffer = useCallback(async () => {
    if (!peerConnectionRef.current || !socket || !partnerId) return;

    const offer = await peerConnectionRef.current.createOffer();
    await peerConnectionRef.current.setLocalDescription(offer);
    
    socket.emit('send-offer', { 
      offer: peerConnectionRef.current.localDescription, 
      target: partnerId 
    });
  }, [socket, partnerId]);

  const handleOffer = useCallback(async (offer: RTCSessionDescriptionInit, callerId: string) => {
    if (!peerConnectionRef.current || !socket) return;

    await peerConnectionRef.current.setRemoteDescription(offer);
    const answer = await peerConnectionRef.current.createAnswer();
    await peerConnectionRef.current.setLocalDescription(answer);

    socket.emit('send-answer', { 
      answer: peerConnectionRef.current.localDescription, 
      target: callerId 
    });
  }, [socket]);

  const handleAnswer = useCallback(async (answer: RTCSessionDescriptionInit) => {
    if (!peerConnectionRef.current) return;
    await peerConnectionRef.current.setRemoteDescription(answer);
  }, []);

  const handleIceCandidate = useCallback(async (candidate: RTCIceCandidateInit) => {
    if (!peerConnectionRef.current) return;
    await peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(candidate));
  }, []);

  const closePeerConnection = useCallback(() => {
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
      peerConnectionRef.current = null;
    }
  }, []);

  return {
    peerConnectionRef,
    localStreamRef,
    createPeerConnection,
    addLocalStream,
    createOffer,
    handleOffer,
    handleAnswer,
    handleIceCandidate,
    closePeerConnection,
  };
};