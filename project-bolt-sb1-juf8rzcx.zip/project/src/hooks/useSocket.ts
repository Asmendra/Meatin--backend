import { useEffect, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';

export const useSocket = (serverUrl: string) => {
  const socketRef = useRef<Socket | null>(null);
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected' | 'error'>('disconnected');
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [reconnectAttempts, setReconnectAttempts] = useState(0);

  useEffect(() => {
    // Don't attempt connection if no server URL is provided
    if (!serverUrl) {
      setConnectionStatus('error');
      return;
    }

    const connectToServer = () => {
      setConnectionStatus('connecting');

      // Create socket connection with better error handling
      socketRef.current = io(serverUrl, {
        transports: ['websocket', 'polling'],
        upgrade: true,
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000,
        timeout: 10000,
        forceNew: true,
      });

      const socket = socketRef.current;

      socket.on('connect', () => {
        console.log('Connected to server:', socket.id);
        setConnectionStatus('connected');
        setReconnectAttempts(0);
      });

      socket.on('disconnect', (reason) => {
        console.log('Disconnected from server:', reason);
        setConnectionStatus('disconnected');
        
        // Auto-reconnect after a delay if not manually disconnected
        if (reason !== 'io client disconnect') {
          scheduleReconnect();
        }
      });

      socket.on('connect_error', (error) => {
        console.warn('Socket connection failed:', error.message);
        setConnectionStatus('error');
        setReconnectAttempts(prev => prev + 1);
        
        // Schedule reconnect with exponential backoff
        scheduleReconnect();
      });

      socket.on('reconnect', (attemptNumber) => {
        console.log('Reconnected after', attemptNumber, 'attempts');
        setConnectionStatus('connected');
        setReconnectAttempts(0);
      });

      socket.on('reconnect_error', (error) => {
        console.warn('Reconnection failed:', error.message);
        setConnectionStatus('error');
      });

      socket.on('reconnect_failed', () => {
        console.error('Failed to reconnect after maximum attempts');
        setConnectionStatus('error');
      });
    };

    const scheduleReconnect = () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      
      // Exponential backoff: 2^attempts * 1000ms, max 30 seconds
      const delay = Math.min(Math.pow(2, reconnectAttempts) * 1000, 30000);
      
      reconnectTimeoutRef.current = setTimeout(() => {
        if (reconnectAttempts < 10) { // Limit total reconnect attempts
          console.log(`Attempting to reconnect... (attempt ${reconnectAttempts + 1})`);
          connectToServer();
        } else {
          console.error('Maximum reconnection attempts reached');
          setConnectionStatus('error');
        }
      }, delay);
    };

    // Initial connection
    connectToServer();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (socketRef.current) {
        socketRef.current.disconnect();
        socketRef.current = null;
      }
      setConnectionStatus('disconnected');
    };
  }, [serverUrl, reconnectAttempts]);

  return { socket: socketRef.current, connectionStatus };
};